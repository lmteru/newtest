import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtoDanoComponent } from './proto-dano.component';

describe('ProtoDanoComponent', () => {
  let component: ProtoDanoComponent;
  let fixture: ComponentFixture<ProtoDanoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProtoDanoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtoDanoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
