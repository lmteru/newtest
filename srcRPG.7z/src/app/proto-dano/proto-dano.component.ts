import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'app-proto-dano',
  templateUrl: './proto-dano.component.html',
  styleUrls: ['./proto-dano.component.css']
})
export class ProtoDanoComponent implements OnInit {

  vidaInicial : number = 100;
  asw : string = "";

  constructor() { }

  ngOnInit() {
  }

  public msg(morto){
    if(morto==false){
      this.asw = "YOU DIED!" ;
    }
  }



}
