import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorsComponentComponent } from './selectors-component.component';

describe('SelectorsComponentComponent', () => {
  let component: SelectorsComponentComponent;
  let fixture: ComponentFixture<SelectorsComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectorsComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectorsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
