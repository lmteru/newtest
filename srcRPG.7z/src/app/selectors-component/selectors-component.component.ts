import { Component, OnInit, OnChanges} from '@angular/core';

@Component({
  selector: 'app-selectors-component',
  templateUrl: './selectors-component.component.html',
  styleUrls: ['./selectors-component.component.css']
})
export class SelectorsComponentComponent implements OnInit {
  constructor() { }
  imgSrc: string ="../images/icon.jpg";
  
  ngOnInit() {
  }

  ngOnChanges(){

  }

  submitChar(raca, classe){

    if(raca=="elfo" && classe=="mago")
      this.imgSrc = "../images/elfo mago.jpg";
    else if(raca=="elfo" && classe=="guerreiro")
      this.imgSrc = "../images/elfo guerreiro.jpg";
    else if(raca=="elfo" && classe=="clerigo")
      this.imgSrc = "../images/elfo clerio.jpg";
    else
      this.imgSrc="../images/icon.jpg";
  }

  showImgSrc(){
    return this.imgSrc;
  }

}
