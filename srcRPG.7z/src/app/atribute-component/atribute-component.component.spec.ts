import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtributeComponentComponent } from './atribute-component.component';

describe('AtributeComponentComponent', () => {
  let component: AtributeComponentComponent;
  let fixture: ComponentFixture<AtributeComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtributeComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtributeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
