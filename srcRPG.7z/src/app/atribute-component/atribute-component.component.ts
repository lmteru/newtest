import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-atribute-component',
  templateUrl: './atribute-component.component.html',
  styleUrls: ['./atribute-component.component.css']
})
export class AtributeComponentComponent implements OnInit {

  @Input() texto: string;
  @Input() valor: number;

  pct: number;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.pct = Math.floor(this.valor/30)*100;
  }

  public ajustarTamanho(): number{
    this.pct = Math.floor((this.valor/30)*100);
    return this.pct;
  }
}
