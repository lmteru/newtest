import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CharImagesComponentComponent } from './char-images-component.component';

describe('CharImagesComponentComponent', () => {
  let component: CharImagesComponentComponent;
  let fixture: ComponentFixture<CharImagesComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CharImagesComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CharImagesComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
