import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-char-images-component',
  templateUrl: './char-images-component.component.html',
  styleUrls: ['./char-images-component.component.css']
})
export class CharImagesComponentComponent implements OnInit {

  constructor() { }
  @Input() raca:string;
  @Input() classe:string;
  case: number;

  ngOnInit() {
    if(this.raca=="elfo" && this.classe=="mago")
      this.case=2;
    if(this.raca=="elfo" && this.classe=="guerreiro")
      this.case=3;
    if(this.raca=="elfo" && this.classe=="clerigo")
      this.case=1;
  }

  ngOnChages(){
    console.log(this.raca);
    console.log(this.classe);
    
    if(this.raca=="elfo" && this.classe=="mago")
    this.case=2;
    if(this.raca=="elfo" && this.classe=="guerreiro")
      this.case=3;
    if(this.raca=="elfo" && this.classe=="clerigo")
      this.case=1;
  }

  getCaso(){
    return this.case;
  }
}
