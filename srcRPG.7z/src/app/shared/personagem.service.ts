import { HoldPersonagensService } from './hold-personagens.service';
import { DadosService } from './../shared/dados.service';
import { Injectable } from '@angular/core';

@Injectable()
export class PersonagemService {

  private dados:DadosService = new DadosService();

  constructor( private save:HoldPersonagensService ) { 
    this.name = "HEROI SEM NOME";
    this.raca = "Humano";
    this.classe = "Guerreiro";
    this.for = this.dados.randomAtribute();
    this.int = this.dados.randomAtribute();
    this.des = this.dados.randomAtribute();
    this.con = this.dados.randomAtribute();
    this.sab = this.dados.randomAtribute();
    this.car = this.dados.randomAtribute();
    this.hp = this.dados.ydx(5,12) + (12*this.dados.modifier(this.$con));
    if(this.hp<10)
      this.hp=10;
    this.ca = 13 + this.dados.modifier(this.$con);
    this.hpAtual = this.hp;
  }

  private name: string;
  private for: number;
  private int: number;
  private des: number;
  private con: number;
  private sab: number;
  private car: number;
  private hp: number;
  private ca: number;
  private hpAtual: number;
  private classe: string;
  private raca: string;



	public get $classe(): string {
		return this.classe;
	}

	public set $classe(value: string) {
		this.classe = value;
	}

	public get $raca(): string {
		return this.raca;
	}

	public set $raca(value: string) {
		this.raca = value;
	}
  
  public get $hp(): number {
    return this.hp;
  }

  public set $hp(value: number) {
    this.hp = value;
  }

  public get $int(): number {
    return this.int;
  }

  public set $int(value: number) {
    this.int = value;
  }

  public get $name(): string {
    return this.name;
  }

  public set $name(value: string) {
    this.name = value;
  }

  public get $for(): number {
    return this.for;
  }

  public set $for(value: number) {
    this.for = value;
  }

  public get $des(): number {
    return this.des;
  }

  public set $des(value: number) {
    this.des = value;
  }

  public get $con(): number {
    return this.con;
  }

  public set $con(value: number) {
    this.con = value;
  }

  public get $sab(): number {
    return this.sab;
  }

  public set $sab(value: number) {
    this.sab = value;
  }

  public get $car(): number {
    return this.car;
  }

  public set $car(value: number) {
    this.car = value;
  }


	public get $ca(): number {
		return this.ca;
	}

	public set $ca(value: number) {
		this.ca = value;
	}

	public get $hpAtual(): number {
		return this.hpAtual;
	}

	public set $hpAtual(value: number) {
		this.hpAtual = value;
	}
  

  public atacaAcerto(arma:string):number{
    let acerto:number;

    acerto = this.dados.randomAtribute();

    if(arma=="corte")
      acerto += this.dados.modifier(this.$for);
    else
      acerto += this.dados.modifier(this.$des);

    return acerto;
  }

  public danoCorte():number{
    return (this.dados.ydx(2,6)+2);
  }

  public danoDist():number{
    return(this.dados.ydx(1,8)+2);
  }

  public toString(){
    let stringFinal = '';

    stringFinal += "NOME: " + this.$name + "\n";

    stringFinal += "FORÇA: " + this.$for+ "\n";
    stringFinal += "DESTREZA: " + this.$des+ "\n";
    stringFinal += "CONSTITUIÇÃO: " + this.$con+ "\n";
    stringFinal += "SABEDORIA: " + this.$sab+ "\n";
    stringFinal += "INTELIGÊNCIA: " + this.$int+ "\n";
    stringFinal += "CARISMA: " + this.$car+ "\n";
    stringFinal += "CA: " + this.$ca+ "\n";
    stringFinal += "HP: " + this.$hp+ "\n";

    return stringFinal;
  }

}
