import { PersonagemService } from './personagem.service';
import { Injectable } from '@angular/core';

@Injectable()
export class HoldPersonagensService {

  constructor() { }

  pilhaPersonagens:PersonagemService[] = [];

  salvaPersonagen(personagem: PersonagemService){
    this.pilhaPersonagens.push(personagem);
    // console.log(this.pilhaPersonagens);
  }

  retornaPilha(){
    return this.pilhaPersonagens;
  }
}
