import { TestBed, inject } from '@angular/core/testing';

import { HoldPersonagensService } from './hold-personagens.service';

describe('HoldPersonagensService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HoldPersonagensService]
    });
  });

  it('should be created', inject([HoldPersonagensService], (service: HoldPersonagensService) => {
    expect(service).toBeTruthy();
  }));
});
