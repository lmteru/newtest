import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-inicial',
  templateUrl: './pagina-inicial.component.html',
  styleUrls: ['./pagina-inicial.component.css']
})
export class PaginaInicialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  imgSrc:string = "https://i.redditmedia.com/fWJUe_RvIOwI_JJSsYsA6mZ2wQnA4NwbomkZFB1_nSM.jpg?w=320&s=5e01437c6ed588a3e459454b32a8a0fa";

}
