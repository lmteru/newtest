import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtoPersonaComponent } from './proto-persona.component';

describe('ProtoPersonaComponent', () => {
  let component: ProtoPersonaComponent;
  let fixture: ComponentFixture<ProtoPersonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProtoPersonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtoPersonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
