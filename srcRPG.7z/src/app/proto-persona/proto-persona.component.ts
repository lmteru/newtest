import { Component, OnInit, Input, Output, OnChanges } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-proto-persona',
  templateUrl: './proto-persona.component.html',
  styleUrls: ['./proto-persona.component.css']
})
export class ProtoPersonaComponent implements OnInit, OnChanges {

  @Input() hp: number;
  @Input() nome: string;

  @Output() mortoEvent = new EventEmitter();

  // nome: string = 'HÉROI';
  vivo:boolean = true;
  inicial: number;
  pct:number = 100;

  constructor() {
   }

  ngOnInit() {
  }

  ngOnChanges() {
    this.inicial = this.hp;
    // console.log(this.inicial);
  }

  public causaDano(dano: number){
    this.hp = this.hp - dano;
    // console.log(this.inicial);
    this.pct = Math.floor((this.hp/this.inicial)*100);
    // console.log(this.pct);
    if(this.hp <= 0){
      this.hp = 0;
      this.pct= 0;
      this.vivo = false;
      this.mortoEvent.emit(this.vivo);
    }
  }

  public showHp():number {
    return this.hp;
  }

  public showPct(): number {
    return this.pct;
  }

  public converteCor(): number {
    if(this.pct >= 85)
      return 1;
      else if(this.pct>25)
          return 2;
    return 3;
  }
}
