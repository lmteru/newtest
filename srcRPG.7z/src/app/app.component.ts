import { Personagem } from './../../../../parte3/RPG/personagem';
import { HoldPersonagensService } from './shared/hold-personagens.service';
import { PersonagemService } from './shared/personagem.service';
import { Component, OnChanges, DoCheck, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private save: HoldPersonagensService){
    let per : PersonagemService = new PersonagemService(save);
    per.$name = 'teste auto';
    
    this.save.salvaPersonagen(per);
    console.log("to criando o personagem default no appComponent");
  }

  title = 'app';

  personagem: PersonagemService;

  numero: number=0;
  
  setRender(numero){
    this.numero=numero;
    // console.log(numero);
  }

  renderWhat(){
    return this.numero;
  }
}