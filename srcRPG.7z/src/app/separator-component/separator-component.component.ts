import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-separator-component',
  templateUrl: './separator-component.component.html',
  styleUrls: ['./separator-component.component.css']
})
export class SeparatorComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
