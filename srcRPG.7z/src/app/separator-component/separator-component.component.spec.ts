import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeparatorComponentComponent } from './separator-component.component';

describe('SeparatorComponentComponent', () => {
  let component: SeparatorComponentComponent;
  let fixture: ComponentFixture<SeparatorComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeparatorComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeparatorComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
