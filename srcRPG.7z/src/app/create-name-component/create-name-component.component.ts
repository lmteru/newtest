import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-name-component',
  templateUrl: './create-name-component.component.html',
  styleUrls: ['./create-name-component.component.css']
})
export class CreateNameComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
