import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuFichasComponent } from './menu-fichas.component';

describe('MenuFichasComponent', () => {
  let component: MenuFichasComponent;
  let fixture: ComponentFixture<MenuFichasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuFichasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuFichasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
