import { PersonagemService } from './../shared/personagem.service';
import { HoldPersonagensService } from './../shared/hold-personagens.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-fichas',
  templateUrl: './menu-fichas.component.html',
  styleUrls: ['./menu-fichas.component.css']
})
export class MenuFichasComponent implements OnInit {
  private arrayPersonagens:PersonagemService[];
  private personagem: PersonagemService;

  private aux = false;

  constructor(private save:HoldPersonagensService) {
    this.arrayPersonagens = save.retornaPilha();
  }

  ngOnInit() {
    // console.log(this.arrayPersonagens[0]);
  }

  changeAux(nome:string){
    let listaNomes:string[]=[];
    for(let per of this.arrayPersonagens)
      listaNomes.push(per.$name);
    
    this.personagem = this.arrayPersonagens[ listaNomes.indexOf(nome) ];
    this.aux= !this.aux;
  }

  isAux(){
    return this.aux;
  }

}
