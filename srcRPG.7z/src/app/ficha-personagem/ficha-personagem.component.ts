import { HoldPersonagensService } from './../shared/hold-personagens.service';
import { Component, OnInit, Input } from '@angular/core';
import { PersonagemService } from '../shared/personagem.service';

@Component({
  selector: 'app-ficha-personagem',
  templateUrl: './ficha-personagem.component.html',
  styleUrls: ['./ficha-personagem.component.css']
})
export class FichaPersonagemComponent implements OnInit {

  @Input() personagem: PersonagemService;

  inicial: number;
  pct:number;

  constructor(private save: HoldPersonagensService) { 
  }

  ngOnInit() {
    this.pct = (this.personagem.$hpAtual/this.personagem.$hp)*100;
    console.log(this.pct);
  }

  public showHp(): number {
    return this.personagem.$hpAtual;
  }

  public showPct(): number {
    return this.pct;
  }

  public converteCor(): number {
    if(this.pct >= 85)
      return 1;
      else if(this.pct>25)
          return 2;
    return 3;
  }
}
