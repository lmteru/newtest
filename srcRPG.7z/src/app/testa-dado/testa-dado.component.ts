import { DadosService } from './../shared/dados.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testa-dado',
  templateUrl: './testa-dado.component.html',
  styleUrls: ['./testa-dado.component.css']
})
export class TestaDadoComponent implements OnInit {

  dadoJogado: number = 6;
  qntDados: number = 52;
  dadoResultadoFinal: number = 0;

  arrayDado = [4, 6, 8, 10, 12, 20, 100];

  constructor(private dado:DadosService) { }

  ngOnInit() {
  }

  getDadoJogado(){
    return this.dadoJogado;
  }

  setDado(dadoSelecionado:number){
    this.dadoJogado = dadoSelecionado;
    console.log(dadoSelecionado);
  }

  setQtd(qtd:number){
    this.qntDados = qtd;
    console.log(qtd);
  }

  jogaDado(){
    let dado:DadosService = new DadosService();

    let dadoResultado = dado.ydx(this.qntDados, this.dadoJogado);

    console.log(dadoResultado);
    
    this.dadoResultadoFinal = dadoResultado;
  }

  newDado(dadoN:number){
    this.arrayDado.push(dadoN);
  }
}
