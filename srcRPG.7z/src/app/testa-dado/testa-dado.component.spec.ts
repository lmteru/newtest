import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestaDadoComponent } from './testa-dado.component';

describe('TestaDadoComponent', () => {
  let component: TestaDadoComponent;
  let fixture: ComponentFixture<TestaDadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestaDadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestaDadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
