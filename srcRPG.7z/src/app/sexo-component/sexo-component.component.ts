import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sexo-component',
  templateUrl: './sexo-component.component.html',
  styleUrls: ['./sexo-component.component.css']
})
export class SexoComponentComponent implements OnInit {

  radioValue: string;
  constructor() { }

  ngOnInit() {
  }

}
