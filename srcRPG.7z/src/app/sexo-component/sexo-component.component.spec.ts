import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SexoComponentComponent } from './sexo-component.component';

describe('SexoComponentComponent', () => {
  let component: SexoComponentComponent;
  let fixture: ComponentFixture<SexoComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SexoComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SexoComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
