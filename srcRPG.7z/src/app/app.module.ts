import { routing } from './app.routing';
import { HoldPersonagensService } from './shared/hold-personagens.service';
import { DadosService } from './shared/dados.service';
import { PersonagemService } from './shared/personagem.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MaterializeModule } from 'angular2-materialize';
import { AppComponent } from './app.component';
import { ProtoDanoComponent } from './proto-dano/proto-dano.component';
import { ProtoPersonaComponent } from './proto-persona/proto-persona.component';
import { FichaPersonagemComponent } from './ficha-personagem/ficha-personagem.component';
import { CreateNameComponentComponent } from './create-name-component/create-name-component.component';
import { SelectorsComponentComponent } from './selectors-component/selectors-component.component';
import { SeparatorComponentComponent } from './separator-component/separator-component.component';
import { AtributeComponentComponent } from './atribute-component/atribute-component.component';
import { AtributeTableComponentComponent } from './atribute-table-component/atribute-table-component.component';
import { SexoComponentComponent } from './sexo-component/sexo-component.component';
import { WrapperComponentComponent } from './wrapper-component/wrapper-component.component';
import { CharImagesComponentComponent } from './char-images-component/char-images-component.component';
import { PaginaInicialComponent } from './pagina-inicial/pagina-inicial.component';
import { CreateCharComponent } from './create-char/create-char.component';
import { TestaDadoComponent } from './testa-dado/testa-dado.component';
import { MenuFichasComponent } from './menu-fichas/menu-fichas.component';


@NgModule({
  declarations: [
    AppComponent,
    ProtoDanoComponent,
    ProtoPersonaComponent,
    FichaPersonagemComponent,
    CreateNameComponentComponent,
    SelectorsComponentComponent,
    SeparatorComponentComponent,
    AtributeComponentComponent,
    AtributeTableComponentComponent,
    SexoComponentComponent,
    WrapperComponentComponent,
    CharImagesComponentComponent,
    PaginaInicialComponent,
    CreateCharComponent,
    TestaDadoComponent,
    MenuFichasComponent
  ],
  imports: [
    BrowserModule,
    MaterializeModule,
    routing
  ],
  providers: [
    PersonagemService,
    DadosService,
    HoldPersonagensService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
