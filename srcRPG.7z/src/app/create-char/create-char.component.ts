import { HoldPersonagensService } from './../shared/hold-personagens.service';
import { PersonagemService } from './../shared/personagem.service';
import { Personagem } from './../../../../../parte3/RPG/personagem';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-char',
  templateUrl: './create-char.component.html',
  styleUrls: ['./create-char.component.css']
})
export class CreateCharComponent implements OnInit {

  constructor(private save: HoldPersonagensService) { }

  classePersonagem:string = "Guerreiro";
  racaPersonagem:string = "Humano";
  nomePersonagem:string = "nomeDefault";

  personagem: PersonagemService;
  arrayPersonagem = [];

  ngOnInit() {
  }

  getClassePersonagem(){
    return this.classePersonagem;
  }

  setClassePersonagem(classePersonagem:string){
    this.classePersonagem = classePersonagem;
  }

  getRacaPersonagem(){
    return this.racaPersonagem;
  }

  setRacaPersonagem(racaPersonagem:string){
    this.racaPersonagem = racaPersonagem;
  }

  getNomePersonagem(){
    return this.nomePersonagem;
  }

  setNomePersonagem(nomePersonagem:string){
    this.nomePersonagem = nomePersonagem;
    console.log(nomePersonagem);
  }

  createChar(){
    this.personagem = new PersonagemService(this.save);
    this.personagem.$name = this.nomePersonagem;
    this.personagem.$classe = this.classePersonagem;
    this.personagem.$raca = this.racaPersonagem;
    this.save.salvaPersonagen(this.personagem);
  }

  showAll(){
    for(let personagem of this.save.retornaPilha())
      console.log(personagem.toString());
  }
}
