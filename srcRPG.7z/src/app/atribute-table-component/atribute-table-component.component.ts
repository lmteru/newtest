import { Component, OnInit, Input } from '@angular/core';
import { PersonagemService } from '../shared/personagem.service';

@Component({
  selector: 'app-atribute-table-component',
  templateUrl: './atribute-table-component.component.html',
  styleUrls: ['./atribute-table-component.component.css']
})
export class AtributeTableComponentComponent implements OnInit {

  @Input() personagem:PersonagemService;
  for: number = 18;
  int: number = 18;
  des: number = 18;
  con: number = 18;
  sab: number = 18;
  car: number = 18;
  ca: number = 18;

  fortxt: string = "FORÇA";
  inttxt: string = "INTELIGENCIA";
  destxt: string = "DESTREZA";
  contxt: string = "CONSTITUIÇÃO";
  sabtxt: string = "SABEDORIA";
  cartxt: string = "CARISMA";
  catxt: string = "CLASSE DE ARMADURA";

  constructor() {
  }

  ngOnInit() {
    this.for = this.personagem.$for;
    this.int = this.personagem.$int;
    this.des = this.personagem.$des;
    this.con = this.personagem.$con;
    this.sab = this.personagem.$sab;
    this.car = this.personagem.$car;

    this.ca = this.personagem.$ca;
  }

}
