import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtributeTableComponentComponent } from './atribute-table-component.component';

describe('AtributeTableComponentComponent', () => {
  let component: AtributeTableComponentComponent;
  let fixture: ComponentFixture<AtributeTableComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtributeTableComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtributeTableComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
