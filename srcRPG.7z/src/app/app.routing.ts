import { PaginaInicialComponent } from './pagina-inicial/pagina-inicial.component';
import { CreateCharComponent } from './create-char/create-char.component';
import { MenuFichasComponent } from './menu-fichas/menu-fichas.component';
import { ProtoDanoComponent } from './proto-dano/proto-dano.component';
import { Component, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { TestaDadoComponent } from './testa-dado/testa-dado.component';

const appRoutes: Routes= [
    {path: 'ProtoDano', component: ProtoDanoComponent},
    {path: 'MenuFichas', component: MenuFichasComponent},
    {path: 'CriarPersonagem', component: CreateCharComponent},
    {path: 'TestaDado', component: TestaDadoComponent},
    {path: 'PaginaInicial', component: PaginaInicialComponent},
    {path: '', component: PaginaInicialComponent}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);