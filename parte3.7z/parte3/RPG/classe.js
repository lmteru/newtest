"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var personagem_1 = require("./personagem");
var Classe = /** @class */ (function (_super) {
    __extends(Classe, _super);
    function Classe(nome, raca) {
        var _this = _super.call(this, nome) || this;
        if (raca == "Elfo") {
            _super.prototype.$des = _super.prototype.$des + 2;
            _super.prototype.$int = _super.prototype.$int + 1;
        }
        else if (raca == "Humano") {
            _super.prototype.$car = +1;
            _super.prototype.$con = +1;
            _super.prototype.$des = +1;
            _super.prototype.$for = +1;
            _super.prototype.$int = +1;
            _super.prototype.$sab = +1;
        }
        else {
            _super.prototype.$for = +2;
            _super.prototype.$con = +1;
        }
        _this.$raca = raca;
        return _this;
    }
    Object.defineProperty(Classe.prototype, "$raca", {
        get: function () {
            return this.raca;
        },
        set: function (value) {
            this.raca = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Classe.prototype, "$classe", {
        get: function () {
            return this.classe;
        },
        set: function (value) {
            this.classe = value;
        },
        enumerable: true,
        configurable: true
    });
    return Classe;
}(personagem_1.Personagem));
exports.Classe = Classe;
var Guerreiro = /** @class */ (function (_super) {
    __extends(Guerreiro, _super);
    function Guerreiro(nome, raca) {
        var _this = _super.call(this, nome, raca) || this;
        _this.$classe = "Guerreiro";
        return _this;
    }
    Guerreiro.prototype.danoCorte = function () {
        var dados;
        return (dados.ydx(2, 6) + 2) * 2;
    };
    return Guerreiro;
}(Classe));
exports.Guerreiro = Guerreiro;
var Mago = /** @class */ (function (_super) {
    __extends(Mago, _super);
    function Mago(nome, raca) {
        var _this = _super.call(this, nome, raca) || this;
        _this.$classe = "Mago";
        return _this;
    }
    Mago.prototype.fireBall = function () {
        var dados;
        var dano;
        dano = dados.ydx(5, 6);
        return dano;
    };
    return Mago;
}(Classe));
exports.Mago = Mago;
var Clerigo = /** @class */ (function (_super) {
    __extends(Clerigo, _super);
    function Clerigo(nome, raca) {
        var _this = _super.call(this, nome, raca) || this;
        _this.$classe = "Clerigo";
        return _this;
    }
    Clerigo.prototype.cura = function () {
        var cura;
        var dados;
        cura = 50 + dados.modifier(_super.prototype.$sab) * 2;
        return cura;
    };
    return Clerigo;
}(Classe));
exports.Clerigo = Clerigo;
