import {Dados} from "./util";
export class Personagem{
    
    private name:string;
    private for:number;
    private int:number;
    private des:number;
    private con:number;
    private sab:number;
	private car:number;
	private hp:number;
	private ca:number;

    constructor(name:string){
        let dados:Dados;

        this.name = name;
        this.for = dados.randomAtribute();
        this.int = dados.randomAtribute();
        this.des = dados.randomAtribute();
        this.con = dados.randomAtribute();
        this.sab = dados.randomAtribute();
		this.car = dados.randomAtribute();
		this.hp = dados.ydx(5,12)+(12*dados.modifier(this.$con));
		this.ca = 13 + dados.modifier(this.$con);
    }


	public get $hp(): number {
		return this.hp;
	}

	public set $hp(value: number) {
		this.hp = value;
	}
	

	public get $int(): number {
		return this.int;
	}

	public set $int(value: number) {
		this.int = value;
	}

	public get $name(): string {
		return this.name;
	}

	public set $name(value: string) {
		this.name = value;
	}

	public get $for(): number {
		return this.for;
	}

	public set $for(value: number) {
		this.for = value;
	}

	public get $des(): number {
		return this.des;
	}

	public set $des(value: number) {
		this.des = value;
	}

	public get $con(): number {
		return this.con;
	}

	public set $con(value: number) {
		this.con = value;
	}

	public get $sab(): number {
		return this.sab;
	}

	public set $sab(value: number) {
		this.sab = value;
	}

	public get $car(): number {
		return this.car;
	}

	public set $car(value: number) {
		this.car = value;
	}

	public atacaAcerto(arma:string):number{
		let acerto:number;
		let dado:Dados;

		acerto = dado.randomAtribute();

		if(arma=="corte")
			acerto =+ dado.modifier(this.$for);
		else
			acerto =+ dado.modifier(this.$des);

		return acerto;
	}

	public danoCorte():number{
		let dado:Dados;

		return (dado.ydx(2,6)+2);
	}

	public danoDist():number{
		let dado:Dados;

		return(dado.ydx(1,8)+2);
	}
}