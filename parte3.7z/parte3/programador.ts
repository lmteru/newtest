import {Funcionario} from "./funcionario"

export class Programador extends Funcionario{

    private participacao:number;

    constructor(nome, salario, horaExtra, vr, vt, participacao){
        super(nome, salario, horaExtra, vr, vt);
        this.participacao = participacao;
    }

    public calculaCustoTotal():number{
        let total:number;

        total = super.calculaCustoTotal() + this.participacao;
        return 
    }
}
