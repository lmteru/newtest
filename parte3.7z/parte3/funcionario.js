"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var Funcionario = /** @class */ (function () {
    function Funcionario(nome, salario, horaExtra, vr, vt) {
        this.nome = nome;
        this.salario = nome;
        this.horaExtra = horaExtra;
        this.vr = vr;
        this.vt = vt;
    }
    Object.defineProperty(Funcionario.prototype, "$nome", {
        get: function () {
            return this.nome;
        },
        set: function (value) {
            this.nome = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Funcionario.prototype, "$horaExtra", {
        get: function () {
            return this.horaExtra;
        },
        set: function (value) {
            this.horaExtra = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Funcionario.prototype, "$salario", {
        get: function () {
            return this.salario;
        },
        set: function (value) {
            this.salario = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Funcionario.prototype, "$vr", {
        get: function () {
            return this.vr;
        },
        set: function (value) {
            this.vr = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Funcionario.prototype, "$vt", {
        get: function () {
            return this.vt;
        },
        set: function (value) {
            this.vt = value;
        },
        enumerable: true,
        configurable: true
    });
    Funcionario.prototype.calculaHoraExtra = function () {
        var total;
        total = 0.75 * this.salario * this.horaExtra;
        return total;
    };
    Funcionario.prototype.calculaCustoTotal = function () {
        var total;
        total = this.salario + 0.75 * this.salario * this.horaExtra + this.vt + this.vr;
        return total;
    };
    return Funcionario;
}());
exports.Funcionario = Funcionario;
var Programador = /** @class */ (function (_super) {
    __extends(Programador, _super);
    function Programador(nome, salario, horaExtra, vr, vt, participacao) {
        var _this = _super.call(this, nome, salario, horaExtra, vr, vt) || this;
        _this.participacao = participacao;
        return _this;
    }
    Programador.prototype.calculaCustoTotal = function () {
        var total;
        total = _super.prototype.calculaCustoTotal.call(this) + this.participacao;
        return;
    };
    return Programador;
}(Funcionario));
var Gerente = /** @class */ (function (_super) {
    __extends(Gerente, _super);
    function Gerente(nome, salario, horaExtra, vr, vt, funcionarios) {
        var _this = _super.call(this, nome, salario, horaExtra, vr, vt) || this;
        _this.funcionarios = funcionarios;
        return _this;
    }
    Gerente.prototype.addFuncionario = function (funcionario) {
        this.funcionarios.push(funcionario);
    };
    Gerente.prototype.calculaCustoTotal = function () {
        var total;
        var i;
        total = _super.prototype.calculaCustoTotal.call(this);
        for (i = 0; i < this.funcionarios.length; i++) {
            total = +this.funcionarios[i].calculaCustoTotal();
        }
        return total;
    };
    Gerente.prototype.calculaFuncionarios = function () {
        var total = 0;
        for (var i = 0; i < this.funcionarios.length; i++)
            total = +this.funcionarios[i].calculaCustoTotal;
        return total;
    };
    return Gerente;
}(Funcionario));
function main() {
    var funcionario = new Funcionario("João", 1500, 0, 400, 200);
    var funcionario0 = new Funcionario("Pedro", 2000, 10, 200, 300);
    var funcionario1 = new Funcionario("Marco", 3000, 40, 400, 200);
    var programador = new Programador("Rafael", 4000, 40, 350, 0, 3000);
    var programador0 = new Programador("Teru", 4000, 300, 500, 0, 6000);
    var funcionarios = [funcionario, funcionario0];
    var gestor = new Gerente("Maria", 7000, 9, 0, 0, funcionarios);
    console.log(gestor);
    console.log(programador);
    console.log(programador0);
    gestor.addFuncionario(funcionario1);
    console.log(gestor);
    console.log(gestor.calculaCustoTotal());
    console.log(gestor.calculaFuncionarios());
    console.log(gestor.calculaHoraExtra());
}
