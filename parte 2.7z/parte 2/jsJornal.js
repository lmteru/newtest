function trocarData(){
    dataTag = document.getElementById("dataID");
    dataTag.innerHTML = "<h3> Nova data = 19/03/2017 </h3>";
}

function AddPreco(){
    var pai = document.getElementsByClassName("coluna");
    var novoElemento = document.createTextNode("CUSTA R$5,00");
    
    pai[pai.length-1].appendChild(novoElemento);
}

function RemoveSubt(){
    var pai = document.getElementsByClassName("coluna");
    var toRemove = document.getElementById("subtitulo");

    pai[0].removeChild(toRemove);
}

function RemoveColumn(){
    if(document.getElementsByClassName("coluna").length>2){
        var pai = document.getElementById("corpo");
        var toRemove = document.getElementsByClassName("coluna");
        toRemove = toRemove[toRemove.length-1];
        
        pai.removeChild(toRemove);
        
        AdjustColumn();
    }
}

function MancheteCap(){
    var manchete = document.getElementById("manchete");
    var txt = manchete.textContent;
    txt = txt.split("");

    for(let i=0;i<txt.length;i++){
        if(i==0 || (txt[i-1] == ' ')){
            txt[i]=txt[i].toUpperCase();
        }
        else
        txt[i] = txt[i].toLowerCase();
    }

    txt=txt.join("");

    manchete.innerText = txt;
    
}

function ThirdColum(){
    var pai = document.getElementById("corpo");

    var novoElemento = document.getElementsByClassName("coluna")[1];
    novoElemento = novoElemento.cloneNode(true);

    //novoElemento.className = "coluna";
    console.log(novoElemento);
    pai.appendChild(novoElemento);

    for(i in document.getElementsByClassName("coluna"))
        document.getElementsByClassName("coluna")[i].setAttribute("style", "width : 30%");
}

function NewColum(){
    var pai = document.getElementById("corpo");
    var elements = document.getElementsByClassName("coluna");
    var tam = 90/(elements.length+1);
    var wdth =  tam + "%";
   
    var novoElemento = elements[elements.length-1].cloneNode(true);

    //novoElemento.className = "coluna";
    console.log(wdth);
    pai.appendChild(novoElemento);
    console.log(elements);
    for(let i=0; i< elements.length;i++)
        elements[i].style.width = wdth;
}

function AdjustColumn(){
    var pai = document.getElementById("corpo");
    var elements = document.getElementsByClassName("coluna");
    var tam = 93/(elements.length+1);
    var wdth =  tam + "%";

    for(let i=0; i< elements.length;i++)
        elements[i].style.width = wdth;
}





trocarData();

//RemoveSubt();
MancheteCap();
//ThirdColum();
// NewColum();
// NewColum();
// NewColum();
// NewColum();
// NewColum();
//AddPreco();