function alterarExib(){
    var texto = document.getElementById("texto");
    var but = document.getElementById("aux").getAttribute("disabled");

    //alert(but);

    if(but == "false"){
        //texto.setAttribute("style","overflow: visible;");
        texto.style.overflowY    ="hidden";
        texto.style.maxHeight = "500px";
        document.getElementById("btnCerto").innerText = "Mostrar Mais";
        document.getElementById("aux").setAttribute("disabled","true");
    }
    else{
        //texto.setAttribute("style","overflow: hidden;");
        texto.style.overflowY = "visible";
        texto.style.maxHeight = "9000000px";
        document.getElementById("btnCerto").innerText = "Mostrar Menos";
        document.getElementById("aux").setAttribute("disabled","false");
    }
       
}

//fuck it
function butMouseOve(){
    var buttom = document.getElementById("mostrarMenos");
    var bot = Math.random() * 300;
    var top = Math.random()* 300;
    var right = Math.random()* 300;
    var left = Math.random()* 300;


    buttom.style.margin = top + "px " + right + "px " + bot + "px " + left +"px";
}

function trocaPeles(){
    var buttom = document.getElementById("btnTroca");
    buttom.innerText = "clica em mim";
    if(buttom.className == "fase1"){
        buttom.className = "fase2";
        buttom.innerText = "não me toque mais";
        buttom.style.backgroundColor = '#'+Math.floor(Math.random()*16777215).toString(16);
    }
    else{
        alert("EU FALEI PRA NÃO ME TOCAR, FUI");
        buttom.className = "fase3";
    }
        
}

function validaNome(){
    var campo = document.getElementsById("nameFD");
    var regEx = /^[a-zA-Z]+$/;

    alert(campo.value);
    
    if(regEx.match(campo.value)){
        alert("tudo OK")
    }else{
        alert("Nome inválido");
        campo.innerText = "";
    }
}