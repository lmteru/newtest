import {Programador} from "./programador"
import {Gerente} from "./gestor"

export class Funcionario{
    private nome:string;
    private salario:number;
    private horaExtra:number;
    private vr:number;
    private vt:number;

    constructor (nome, salario, horaExtra, vr, vt){
         this.nome=nome;
         this.salario=nome;
         this.horaExtra=horaExtra;
         this.vr=vr;
         this.vt=vt;
    }

	public get $nome(): string {
		return this.nome;
	}

	public set $nome(value: string) {
		this.nome = value;
	}

	public get $horaExtra(): number {
		return this.horaExtra;
	}

	public set $horaExtra(value: number) {
		this.horaExtra = value;
	}

	public get $salario(): number {
		return this.salario;
	}

	public set $salario(value: number) {
		this.salario = value;
	}

	public get $vr(): number {
		return this.vr;
	}

	public set $vr(value: number) {
		this.vr = value;
	}

	public get $vt(): number {
		return this.vt;
	}

	public set $vt(value: number) {
		this.vt = value;
    }
    
    public calculaHoraExtra():number{
        let total:number;

        total = 0.75*this.salario*this.horaExtra;

        return total;
    }
    
    public calculaCustoTotal():number{
        let total:number;

        total = this.salario + 0.75*this.salario*this.horaExtra + this.vt + this.vr;

        return total;
    }
}

interface FuncionarioConfig{
    nome:string;
    salario:string;
    horaExtra?:number;
    vr?:number;
    vt?:number;
}

function main(){
    let funcionario = new Funcionario("João", 1500, 0, 400, 200);
    let funcionario0 = new Funcionario("Pedro", 2000, 10, 200, 300);
    let funcionario1 = new Funcionario("Marco", 3000, 40, 400, 200);

    let programador = new Programador("Rafael", 4000, 40, 350, 0, 3000);
    let programador0 = new Programador("Teru", 4000, 300, 500, 0, 6000);
    
    let funcionarios: Array<Funcionario>  = [funcionario, funcionario0];

    let gestor = new Gerente("Maria", 7000, 9, 0,0,funcionarios);


    console.log(gestor);
    console.log(programador);
    console.log(programador0);

    gestor.addFuncionario(funcionario1);

    console.log(gestor);

    console.log(gestor.calculaCustoTotal());

    console.log(gestor.calculaFuncionarios());

    console.log(gestor.calculaHoraExtra());



}