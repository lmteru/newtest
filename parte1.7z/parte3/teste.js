// function teste1(){
//     let count:number = 5;
//     enum Cores {Vermelho, Azul, Amarelo};
//     let msg;
//     msg = "asd";
//     let terminaComD = (<string>msg).endsWith('d');
// }
var TestClass = /** @class */ (function () {
    function TestClass() {
    }
    TestClass.main = function () {
        console.log("Hello WOrkd!");
        return 0;
    };
    return TestClass;
}());
TestClass.main();
var Point = /** @class */ (function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }
    Point.prototype.getX = function () { return this.x; };
    Point.prototype.setX = function (x) { this.x = x; };
    return Point;
}());
var p = new Point(10, 5);
var x = p.getX();
p.setX(15);


