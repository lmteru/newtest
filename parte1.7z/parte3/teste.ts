// // function teste1(){
// //     let count:number = 5;
// //     enum Cores {Vermelho, Azul, Amarelo};

// //     let msg;
// //     msg = "asd";

// //     let terminaComD = (<string>msg).endsWith('d');
// // }

// class TestClass{
//     public static main(){
//         console.log("Hello WOrkd!");
//         return 0;
//     }
// }

// TestClass.main();

// class Point{
//     // x:number;
//     // y:number;
//     constructor(private x?:number, private y?:number){}
//         getX(){return this.x;}
//         setX(x){this.x=x;}
// }
//     let p = new Point(10,5);
//     let x = p.getX();
//     p.setX(15);


    class livro{
        private nome:string;
        private autor:string;
        private editora:string;
        private lacamento:number;
        private paginas:number;
        private locacao:number;


        constructor(nome,autor,editora,lacamento,paginas, locacao) {
            this.nome = nome;
            this.autor = autor;
            this.editora = editora;
            this.lacamento = lacamento;
            this.paginas = paginas;
            this.locacao = locacao;
        }
        
        public get $nome(): string {
            return this.nome;
        }

        public set $nome(value: string) {
            this.nome = value;
        }

        public get $autor(): string {
            return this.autor;
        }

        public get $editora(): string {
            return this.editora;
        }

        public set $editora(value: string) {
            this.editora = value;
        }

        public get $paginas(): number {
            return this.paginas;
        }

        public set $paginas(value: number) {
            this.paginas = value;
	    }
        

    }