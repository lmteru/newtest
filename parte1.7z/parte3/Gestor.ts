import {Funcionario} from "./funcionario"


export class Gerente extends Funcionario{
    
    private funcionarios:Funcionario[];

    constructor(nome, salario, horaExtra, vr, vt, funcionarios){
        super(nome, salario, horaExtra, vr, vt);
        this.funcionarios = funcionarios;
    }

    addFuncionario(funcionario:Funcionario){
        this.funcionarios.push(funcionario);
    }

    public calculaCustoTotal():number{
        let total:number;
        let i:number;
        total = super.calculaCustoTotal();

        for(i=0;i<this.funcionarios.length;i++){
            total =+ this.funcionarios[i].calculaCustoTotal();
        }

        return total;
    }

    public calculaFuncionarios():number{
        let total:number = 0;

        for(let i=0;i<this.funcionarios.length;i++)
            total =+ this.funcionarios[i].calculaCustoTotal;

        return total;
    }
}