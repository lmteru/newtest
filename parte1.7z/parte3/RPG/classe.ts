import {Dados} from "./util"
import {Personagem} from "./personagem";

export class Classe extends Personagem{
    private classe:string;
    private raca:string;

    constructor(nome:string, raca:string){
        super(nome);
        if(raca=="Elfo"){
            super.$des = super.$des +2;
            super.$int = super.$int +1;
        }else 
            if(raca=="Humano"){
                super.$car =+ 1;
                super.$con =+ 1;
                super.$des =+ 1;
                super.$for =+ 1;
                super.$int =+ 1;
                super.$sab =+ 1;
            }else {
                super.$for =+ 2;
                super.$con =+ 1;
            }
        
        this.$raca = raca;
        
    }

	public get $raca(): string {
		return this.raca;
	}

	public set $raca(value: string) {
		this.raca = value;
    }
    
	public get $classe(): string {
		return this.classe;
	}

	public set $classe(value: string) {
		this.classe = value;
	}
}

export class Guerreiro extends Classe{

    constructor(nome:string, raca:string){
        super(nome, raca);
        this.$classe = "Guerreiro";
    }

    public danoCorte():number{
        let dados:Dados;
        
        return (dados.ydx(2,6)+2)*2;
    }
}

export class Mago extends Classe{

    constructor(nome:string, raca:string){
        super(nome, raca);
        this.$classe="Mago";
    }

    public fireBall():number{
        let dados:Dados;
        let dano:number;

        dano = dados.ydx(5,6);

        return dano;
    }
}

export class Clerigo extends Classe{

    constructor(nome:string, raca:string){
        super(nome, raca);
        this.$classe="Clerigo";
    }

    public cura():number{
        let cura:number;
        let dados:Dados;
        
        cura = 50 + dados.modifier(super.$sab)*2; 

        return cura;
    }
}