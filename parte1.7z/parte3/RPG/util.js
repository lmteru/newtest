"use strict";
exports.__esModule = true;
var Dados = /** @class */ (function () {
    function Dados() {
    }
    ;
    Dados.prototype.ydx = function (y, x) {
        var a = (Math.random() + 1) * x;
        a = Math.floor(a);
        return a * y;
    };
    Dados.prototype.randomAtribute = function () {
        var result = 0;
        var dados = [this.ydx(1, 6), this.ydx(1, 6), this.ydx(1, 6), this.ydx(1, 6)];
        var menor, index;
        menor = dados[0];
        index = 0;
        for (var i = 1; i < 4; i++) {
            if (menor > dados[i]) {
                menor = dados[i];
                index = i;
            }
        }
        for (var i = 1; i < 4; i++)
            if (i != index)
                result = +dados[i];
        return result;
    };
    Dados.prototype.modifier = function (atb) {
        atb = Math.floor(atb / 2);
        atb = -5;
        return atb;
    };
    return Dados;
}());
exports.Dados = Dados;
