export class Dados{
    constructor(){};

    public ydx(y:number, x:number):number{
        let a:number = (Math.random()+1) *x;
        a = Math.floor(a);

        return a*y;
    }

    public randomAtribute():number{
        let result:number = 0;
        let dados:Array<number> = [this.ydx(1,6), this.ydx(1,6), this.ydx(1,6), this.ydx(1,6)];
        let menor : number , index:number;

        menor = dados[0];
        index = 0;

        for(let i=1;i<4;i++){
            if(menor > dados[i]){
                menor = dados[i];
                index = i;
            }
        }

        for(let i=1;i<4;i++)
            if(i!=index)
                result =+ dados[i];


        return result;
    }

    public modifier(atb:number):number{
        atb=Math.floor(atb/2);
        atb =- 5;

        return atb;
    }
}
