"use strict";
exports.__esModule = true;
var Personagem = /** @class */ (function () {
    function Personagem(name) {
        var dados;
        this.name = name;
        this["for"] = dados.randomAtribute();
        this.int = dados.randomAtribute();
        this.des = dados.randomAtribute();
        this.con = dados.randomAtribute();
        this.sab = dados.randomAtribute();
        this.car = dados.randomAtribute();
        this.hp = dados.ydx(5, 12) + (12 * dados.modifier(this.$con));
        this.ca = 13 + dados.modifier(this.$con);
    }
    Object.defineProperty(Personagem.prototype, "$hp", {
        get: function () {
            return this.hp;
        },
        set: function (value) {
            this.hp = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$int", {
        get: function () {
            return this.int;
        },
        set: function (value) {
            this.int = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$name", {
        get: function () {
            return this.name;
        },
        set: function (value) {
            this.name = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$for", {
        get: function () {
            return this["for"];
        },
        set: function (value) {
            this["for"] = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$des", {
        get: function () {
            return this.des;
        },
        set: function (value) {
            this.des = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$con", {
        get: function () {
            return this.con;
        },
        set: function (value) {
            this.con = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$sab", {
        get: function () {
            return this.sab;
        },
        set: function (value) {
            this.sab = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Personagem.prototype, "$car", {
        get: function () {
            return this.car;
        },
        set: function (value) {
            this.car = value;
        },
        enumerable: true,
        configurable: true
    });
    Personagem.prototype.atacaAcerto = function (arma) {
        var acerto;
        var dado;
        acerto = dado.randomAtribute();
        if (arma == "corte")
            acerto = +dado.modifier(this.$for);
        else
            acerto = +dado.modifier(this.$des);
        return acerto;
    };
    Personagem.prototype.danoCorte = function () {
        var dado;
        return (dado.ydx(2, 6) + 2);
    };
    Personagem.prototype.danoDist = function () {
        var dado;
        return (dado.ydx(1, 8) + 2);
    };
    return Personagem;
}());
exports.Personagem = Personagem;
