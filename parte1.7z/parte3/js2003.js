function atualizaHora() {
    var d = new Date();
    var myDate = d.getHours() + " : " + d.getMinutes();
    var botao = document.getElementById("btnHora");
    var lblPai = document.getElementById("addHere");
    if (botao.className == "fase1") {
        botao.className = "fase2";
        botao.value = "Apagar a hora";
        var elementoNovo = document.createElement("H3");
        elementoNovo.innerText = "Hora atual " + myDate;
        elementoNovo.className = "timeTxtFld";
        lblPai.appendChild(elementoNovo);
    }
    else {
        botao.className = "fase1";
        botao.value = "Mostrar as horas";
        var toDelete = document.getElementsByClassName("timeTxtFld")[0];
        lblPai.removeChild(toDelete);
    }
}
function tres() {
    var lblPai = document.getElementById("addHere");
    var elementoNovo = document.createElement("H3");
    elementoNovo.innerText = "3 - tres";
    elementoNovo.className = "toDelete";
    lblPai.appendChild(elementoNovo);
}
function calculadoraVezes() {
    var x = document.getElementById("op1").value;
    var y = document.getElementById("op2").value;
    var res = document.getElementById("res");
    if (Number(x) / Number(y) == null) {
        alert("ESSA PORRA NÃO É UM NUMERO");
    }
    else
        res.innerText = Number(x) * Number(y);
}
function calculadoraMais() {
    var x = document.getElementById("op1").value;
    var y = document.getElementById("op2").value;
    var res = document.getElementById("res");
    if (Number(x) / Number(y) == NaN) {
        alert("ESSA PORRA NÃO É UM NUMERO");
    }
    else
        res.innerText = Number(x) + Number(y);
}
function calculadoraMenos() {
    var x = document.getElementById("op1").value;
    var y = document.getElementById("op2").value;
    var res = document.getElementById("res");
    if (Number(x) / Number(y) == NaN) {
        alert("ESSA PORRA NÃO É UM NUMERO");
    }
    else
        res.innerText = Number(x) - Number(y);
}
function calculadoraDiv() {
    var x = document.getElementById("op1").value;
    var y = document.getElementById("op2").value;
    var res = document.getElementById("res");
    if (Number(x) / Number(y) === NaN) {
        alert("ESSA PORRA NÃO É UM NUMERO");
    }
    else
        res.innerText = Number(x) / Number(y);
}
// function tecla(){
//     //console.log(event);
//     var pKey = event.keyCode;
//     var element = document.getElementById("tekla");
//     element.innerText = pKey;
// }
function key(e) {
    document.getElementById("clicado").textContent = e.key;
    console.log(e);
}
