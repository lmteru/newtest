function Capitalize(entrada){
    entrada=entrada.split("");
    for(let i = 0; i<entrada.length; i++){
        entrada[i] = Number(entrada[i].charCodeAt(0));

        if(i==0 || (entrada[i-1] == " ")){
            if(entrada[i] >= 97 && entrada[i] <= 122)
                entrada[i] -= 32;
        }
        else{
            if(entrada[i] >= 65 && entrada[i] <= 90){
                entrada[i] += 32;
            }
        }

        entrada[i] = String.fromCharCode(entrada[i]);
    }

    entrada = entrada.join("");
    console.log(entrada);
    //alert(entrada);   
}

function Capitalize2(entrada){
    entrada = entrada.split("");

    for(let i=0;i<entrada.length;i++){
        if(i==0 || (entrada[i-1] == ' ')){
            entrada[i]=entrada[i].toUpperCase();
        }
        else
            entrada[i] = entrada[i].toLowerCase();
    }

    entrada=entrada.join("");
    console.log(entrada);
}

function Capitalize3(entrada){
    var plv = entrada.split(" ");

    for(p in plv){
        plv[p] = plv[p][0].toUpperCase() + plv[p].substring(1).toLowerCase();
    }
    entrada = plv.join(" ");

    console.log(entrada);
}

function PalavraMaior(entrada){
    var resposta;
    var palavra;

    entrada = entrada.split(" ");
    resposta = entrada[0].split("");

    for(let i=1;i<entrada.length;i++){
        palavra = entrada[i].split("");
        if(palavra.length > resposta.length){
            resposta = palavra;
        }    
    }

    resposta = resposta.join("");
    console.log(resposta + ", que tem " + resposta.length + " letras");
    //alert(resposta);
}


function Vogais(entrada){
    var qnt = 0;
    entrada = entrada.toLowerCase();
    //entrada = entrada.split("");

    // for(let i=0; i<entrada.length; i++)
    for(i in entrada)
        if(entrada[i]=='a' ||entrada[i]=='e' ||entrada[i]=='i' ||entrada[i]=='o' ||entrada[i]=='u')
            qnt++;

    console.log(qnt);
    //alert(entrada.length);
}


// Capitalize3("testando uma Primeira EnTraDa");
// Capitalize3("Tstando UmA Segunda EnTrada");

// PalavraMaior("A maior palavra da frase e essaaaaaaaaa");
// PalavraMaior("segudonte teste a maior ta AQUIIIIIIIIIIII");

Vogais("conta as frases");
Vogais("conte as vogais");
Vogais("iiiiaaaaiiiioooooddddasdasjdhaskjda");
