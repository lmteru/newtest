function Livro(nome, autor, numPag, lido, editora){
    this.nome = nome;
    this.autor = autor;
    this.numPag = numPag;
    this.lido = lido;
    this.editora = editora;
}

function testeLivro(){
    
    //function Livro(nome, autor, numPag, lido, editora){
    var livro0 = new Livro("A batalha do apocalipse", "Eduardo Spohr", 586, 1, "Versus");
    var livro1 = new Livro("Deuses de dois mundos", "PJ Pereira", 344, 1, "Da Boa Prosa");
    var livro2 = new Livro("A torre negra: O pistoleiro", "Stephen King", 300, 0, "Suma");
    var livro3 = new Livro("Eragon", "Christopher Paolini", 0, 1, "Rocco");
    
    var imprime = function (){

        livros = [livro0, livro1, livro2, livro3];
        var acc = "";

        for(livro in livros){
            acc += livros[livro].nome + " é um livro de " + livros[livro].autor + " da editora " 
            + livros[livro].editora + " tem " + livros[livro].numPag + " páginas, ";

            (livros[livro].lido) ? acc += "e eu ja o li.\n" : acc += "e eu ainda vou ler ele.\n";

        }

        return(acc);
    }
    
    console.log(imprime());
}























function Receita(titulo, serve, ingr){
    this.titulo = titulo;
    this.serve = serve;
    this.Ingredientes = function (nome, unidade, quantidade){
            this.nome = nome;
            this.quantidade = quantidade;
            this.unidade = unidade;
        
            this.lista = function(){
                return this.quantidade + " " + this.unidade + " de " + this.nome + "\n"
            }
    }

    this.imprime = function(){
        var acc = "Receita de " + this.titulo + "\n\n serve " + this.serve + " pessoas \n\n";
        for (ing in ingr)
            acc += ingr[ing].lista();
        
            return acc;
    }
    
}

function Receitas(){
    var ingredientes1 = [new Ingredientes("Farinha", "gramas", 500), new Ingredientes("Ovos", "unidades", 5),
    new Ingredientes("Sal", "colheres de chá", 3)];

    var receita1 = new Receita("Massa de Macarrão", 2, ingredientes1);

    console.log(receita1.imprime());
}

Receitas();

//testeLivro();