function e1(vetor){
    var maior = vetor[0];
    var menor = vetor[0];
    for(let i=0;i<vetor.length; i++){
        if(maior < vetor[i]) maior = vetor[i];
        if(menor > vetor[i]) menor = vetor[i];
    }

    alert("o menor é : " + menor + ", o maior é : " + maior +  ".");
}

function par(vetor, numero){
    var soma=0;
    var resposta = [];
    for(let a=0;a<vetor.length;a++){
        for(let b=0;b<vetor.length;b++){
            if(a==b) b++;
            if(b<vetor.length)
                if((vetor[a]+vetor[b])==numero) resposta = [vetor[a], vetor[b]];
        }
    }

    alert("resposta : " + resposta);
}

function parMelhor(vetor, numero){

    var resposta = [];
    var aux = [];

    for(let i=0; i<vetor.length; i++){
        aux[numero - vetor[i]] =  1;
    }

    for(let i=0; i<vetor.length; i++){
        if(aux[numero - vetor[i]] ==  1) reposta = [ vetor[i], numero - vetor[i]];
    }

    alert(resposta);

}

function expressao(){
    var fatorial = function fat(n){return n<2 ? 1 : n*fat(n-1);};
    var x = fatorial(3);
    var y = fatorial(5);

    alert("x = " + x + ",y = " + y + ".");
}


e1([10, 20, 30, 40, 50]);
e1([11,879, 6, 7, 1, 74, 59, 2]);

par([10, 30, 40, 20, 5], 15);
par([10, 30, 40, 50, 60], 80);

parMelhor([10, 30, 40, 20, 5], 15);
parMelhor([10, 30, 40, 50, 60], 80);