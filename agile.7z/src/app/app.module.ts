import { SlidesService } from './shared/slides.service';
import { StateService } from './shared/state.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MaterializeModule } from 'angular2-materialize';


import { AppComponent } from './app.component';
import { MenuLateralComponent } from './menu-lateral/menu-lateral.component';
import { TelaApresentacaoComponent } from './tela-apresentacao/tela-apresentacao.component';
import { MenuSuperiorComponent } from './menu-superior/menu-superior.component';
import { TimerBarComponent } from './timer-bar/timer-bar.component';
import { MultipleVariablesService } from './shared/multiple-variables.service';
import { SlideContentComponent } from './slide-content/slide-content.component';


@NgModule({
  declarations: [
    AppComponent,
    MenuLateralComponent,
    TelaApresentacaoComponent,
    MenuSuperiorComponent,
    TimerBarComponent,
    SlideContentComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [
    MultipleVariablesService,
    StateService,
    SlidesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
