import { MultipleVariablesService } from './../shared/multiple-variables.service';
import { Component, OnInit, Output } from '@angular/core';
import { StateService } from '../shared/state.service';
import { SlideContentComponent } from '../slide-content/slide-content.component';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-timer-bar',
  templateUrl: './timer-bar.component.html',
  styleUrls: ['./timer-bar.component.css']
})
export class TimerBarComponent implements OnInit {

  inicial: number = 10;
  atual: number;
  pct: number;

  constructor( private varHold: MultipleVariablesService, private stateManip: StateService) {
    this.atual = this. inicial;
    stateManip.headerManip();
  }

  ngOnInit() {
    var m = setInterval( m=>
      {
        if(this.varHold.getTimer())
          this.atual--;

        if(this.atual==0){
          this.varHold.showTimerEnd = true;
          this.stateManip.headerManip();
          this.varHold.setChangeSlide(true);
          this.atual = this.inicial = this.stateManip.getTime();
          this.stateManip.nextState();
        }
      }
      , 1000 )
  }

  getPct(): number{

    this.pct = Math.floor(this.atual/this.inicial*100);
    return this.pct;
  }

}
