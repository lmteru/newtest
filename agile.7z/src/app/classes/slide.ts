export class Slide {
    constructor() {
    }
    titulo: string;
    conteudo: string;
}

