import { StateService } from './../shared/state.service';
import { MultipleVariablesService } from './../shared/multiple-variables.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-lateral',
  templateUrl: './menu-lateral.component.html',
  styleUrls: ['./menu-lateral.component.css']
})
export class MenuLateralComponent implements OnInit {

  constructor(private varHold:MultipleVariablesService, private stateManip: StateService ) {  }

  ngOnInit() {
  }

  pauseTimer(){
    this.varHold.pauseTimer();
  }

  runTimer(){
    this.varHold.runTimer();
  }

  goToNext(){
    this.stateManip.nextState();
    this.stateManip.headerManip();
    this.varHold.setChangeSlide(true);
  }

  returnSlide(){
    this.stateManip.previousState();
    this.stateManip.headerManip();
    this.varHold.setChangeSlide(true);
  }

}
