import { Component, OnInit } from '@angular/core';

import { MultipleVariablesService } from './../shared/multiple-variables.service';
import { SlidesService } from './../shared/slides.service';
import { Slide } from '../classes/slide';
import { StateService } from '../shared/state.service';

@Component({
  selector: 'app-slide-content',
  templateUrl: './slide-content.component.html',
  styleUrls: ['./slide-content.component.css']
})
export class SlideContentComponent implements OnInit {

  private s:Slide

  constructor(private slides:SlidesService, private varHold: MultipleVariablesService
    , private stateManip: StateService) { }

  ngOnInit() {
    this.s = this.slides.slides[0];
    var m = setInterval( m=>
      {
        if(this.varHold.isChangeSlide())
        {
          //console.log(this.stateManip.getState());
          //this.varHold.pauseTimer();
          this.s = this.slides.slides[this.stateManip.getState()];
          this.varHold.setChangeSlide(false);
        }

      }
      , 1 )
  }

  ngOnChanges(){

  }

  changeText(){
    this.s = this.slides.slides[this.stateManip.getState()];
  }


}
