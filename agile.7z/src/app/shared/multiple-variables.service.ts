import { Injectable } from '@angular/core';

@Injectable()
export class MultipleVariablesService {

  showTimerEnd: boolean = false;
  private setTimer: boolean = false;
  private changeSlide: boolean = false;

  private arrayHeaderText: string[] = [];

  constructor() { }

  pauseTimer(){
    this.setTimer = false;
  }

  runTimer(){
    this.setTimer = true;
  }

  getTimer(){
    return this.setTimer;
  }
  //
  getHeaderText(){
    return this.arrayHeaderText;
  }

  pushHeaderTexte( toAdd: string ){
    this.arrayHeaderText.push(">");
    this.arrayHeaderText.push(toAdd);
  }
  //
  isChangeSlide(){
    return this.changeSlide;
  }

  setChangeSlide( toChange: boolean ){
    this.changeSlide = toChange;
  }

}
