import { Injectable } from '@angular/core';
import { Slide } from '../classes/slide';

@Injectable()
export class SlidesService {
  constructor() { }

  slides:Slide[] = [
    {
      titulo: "Agile",
      conteudo: "Entrega rapida de software funcional com grande aceitação" 
      + " de mudanças de requisitos. Equipe alto gerenciavel com mais contato com a area de buisness"
    },
    {
      titulo: "Scrum",
      conteudo: "Framework para colaboração eficente de um time em projetos complexos"
    },
    {
      titulo: "segundo slide",
      conteudo: "segundo texto"
    }
  ]
}
