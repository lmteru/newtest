import { Injectable } from '@angular/core';

import { MultipleVariablesService } from './multiple-variables.service';

@Injectable()
export class StateService {

  private estadoAtual: number = 0;
  private tempoState: number = 100;

  constructor( private varHold: MultipleVariablesService ) { }

  getState(): number{
    return this.estadoAtual;
  }

  nextState(){
    this.estadoAtual++;
    return this.estadoAtual;
  }

  previousState(){
    this.estadoAtual--;
    return this.estadoAtual;
  }

  getTime(){
    return this.tempoState;
  }

  headerManip(){
    switch(this.estadoAtual){
      case(0):
        this.varHold.pushHeaderTexte("METODO AGIL");
        this.tempoState = 10;
        break;
      case(1):
        this.varHold.pushHeaderTexte("KANBAN");
        this.tempoState = 10;
        // this.varHold.pauseTimer();
        break;
      case(2):
        this.varHold.pushHeaderTexte("SCRUM");
        this.tempoState = 10;

        break;
      case(3):
        this.varHold.pushHeaderTexte("XP");
        this.tempoState = 10;

        break;
      case(4):
        this.varHold.pushHeaderTexte("FIM");
        this.tempoState = 20;
        this.varHold.pauseTimer();
        break;




    }
  }
}
