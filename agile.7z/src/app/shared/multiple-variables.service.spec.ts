import { TestBed, inject } from '@angular/core/testing';

import { MultipleVariablesService } from './multiple-variables.service';

describe('MultipleVariablesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MultipleVariablesService]
    });
  });

  it('should be created', inject([MultipleVariablesService], (service: MultipleVariablesService) => {
    expect(service).toBeTruthy();
  }));
});
