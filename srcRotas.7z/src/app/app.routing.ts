import { TimeComponent } from './time/time.component';
import { Component, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";

import { ListaTimesComponent } from './lista-times/lista-times.component';
import { JogadorComponent } from './jogador/jogador.component';
import { HomeComponent } from './home/home.component';

const appRoutes: Routes= [
    { path: '', component: HomeComponent},
    { path: 'lista', component: ListaTimesComponent},
    { path: 'jogador', component: JogadorComponent},
    { path: 'time/:meuTime', component: TimeComponent}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);