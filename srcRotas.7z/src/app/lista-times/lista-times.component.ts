import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-times',
  templateUrl: './lista-times.component.html',
  styleUrls: ['./lista-times.component.css']
})
export class ListaTimesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
