import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-receive-show-component',
  templateUrl: './text-receive-show-component.component.html',
  styleUrls: ['./text-receive-show-component.component.css']
})
export class TextReceiveShowComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
