import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compose-card-component',
  templateUrl: './compose-card-component.component.html',
  styleUrls: ['./compose-card-component.component.css']
})
export class ComposeCardComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
