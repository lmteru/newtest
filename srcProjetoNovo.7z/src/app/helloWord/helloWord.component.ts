import { Component } from '@angular/core';

@Component({
    selector : 'app-hello-word',
    template: `<h1>HELLO WORLD!</h1>`
})

export class HelloWorldComponent { }
