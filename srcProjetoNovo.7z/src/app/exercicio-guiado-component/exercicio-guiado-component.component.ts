import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercicio-guiado-component',
  templateUrl: './exercicio-guiado-component.component.html',
  styleUrls: ['./exercicio-guiado-component.component.css']
})
export class ExercicioGuiadoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
