import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pf-favoritos-component',
  templateUrl: './pf-favoritos-component.component.html',
  styleUrls: ['./pf-favoritos-component.component.css']
})
export class PfFavoritosComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
