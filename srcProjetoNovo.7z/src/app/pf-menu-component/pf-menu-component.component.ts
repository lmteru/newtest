import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pf-menu-component',
  templateUrl: './pf-menu-component.component.html',
  styleUrls: ['./pf-menu-component.component.css']
})
export class PfMenuComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
