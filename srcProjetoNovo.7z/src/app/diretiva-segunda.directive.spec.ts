import { DiretivaSegundaDirective } from './diretiva-segunda.directive';

describe('DiretivaSegundaDirective', () => {
  it('should create an instance', () => {
    const directive = new DiretivaSegundaDirective();
    expect(directive).toBeTruthy();
  });
});
