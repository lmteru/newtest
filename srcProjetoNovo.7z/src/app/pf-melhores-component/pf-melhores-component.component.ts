import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pf-melhores-component',
  templateUrl: './pf-melhores-component.component.html',
  styleUrls: ['./pf-melhores-component.component.css']
})
export class PfMelhoresComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
