import { TesteDiretivaDirective } from './teste-diretiva.directive';

describe('TesteDiretivaDirective', () => {
  it('should create an instance', () => {
    const directive = new TesteDiretivaDirective();
    expect(directive).toBeTruthy();
  });
});
