import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-separador-component',
  templateUrl: './separador-component.component.html',
  styleUrls: ['./separador-component.component.css']
})
export class SeparadorComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
