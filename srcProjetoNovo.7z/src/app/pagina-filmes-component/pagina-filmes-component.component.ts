import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-filmes-component',
  templateUrl: './pagina-filmes-component.component.html',
  styleUrls: ['./pagina-filmes-component.component.css']
})
export class PaginaFilmesComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
